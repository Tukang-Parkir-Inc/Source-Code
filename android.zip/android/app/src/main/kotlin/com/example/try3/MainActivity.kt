package com.example.try3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
