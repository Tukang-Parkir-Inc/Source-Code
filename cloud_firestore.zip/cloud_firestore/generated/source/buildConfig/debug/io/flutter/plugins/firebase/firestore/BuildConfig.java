/**
 * Automatically generated file. DO NOT MODIFY
 */
package io.flutter.plugins.firebase.firestore;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "io.flutter.plugins.firebase.firestore";
  public static final String BUILD_TYPE = "debug";
  // Field from default config.
  public static final String LIBRARY_NAME = "flutter-fire-fst";
  // Field from default config.
  public static final String LIBRARY_VERSION = "5.6.0";
}
