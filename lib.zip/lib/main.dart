import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'pages/loadingPage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (e) {
    print('Error initializing Firebase: $e');
  }
  runApp(const TukangParkirApp());
}

class TukangParkirApp extends StatelessWidget {
  const TukangParkirApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Disable debug banner
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color.fromARGB(255, 255, 255, 255),
      ),
      home: LoadingPage(), // Starting page of your app
    );
  }
}
