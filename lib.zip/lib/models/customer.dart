import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/reservation.dart';
import 'user.dart';

class Customer extends User {
  String address;
  String email;
  String fullName;
  String plateNum;
  List<Reservation>? history;

  Customer({
    required int userID,
    required String username,
    required String password,
    required String role,
    required this.address,
    required this.email,
    required this.fullName,
    required this.plateNum,
    this.history,
  }) : super(
          userID: userID,
          username: username,
          password: password,
          role: role,
        );

  @override
  Map<String, dynamic> toJson() {
    final userJson = super.toJson();
    return {
      ...userJson,
      'address': address,
      'email': email,
      'fullName': fullName,
      'plateNum': plateNum,
      'history': history?.map((r) => r.toJson()).toList() ??
          [], // Handle null with a fallback to empty list
    };
  }

  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      userID: json['userID'],
      username: json['username'],
      password: json['password'],
      role: json['role'],
      address: json['address'],
      email: json['email'],
      fullName: json['fullName'],
      plateNum: json['plateNum'],
      history: (json['history'] as List<dynamic>?)
          ?.map((item) {
            if (item is Map<String, dynamic>) {
              return Reservation.fromJson(item);
            }
            return null;
          })
          .whereType<Reservation>() // Filter out null values
          .toList(),
    );
  }

  // Method to update customer details
  void updateCustomer({
    String? newUsername,
    String? newPassword,
    String? newRole,
    String? newAddress,
    String? newEmail,
    String? newFullName,
    String? newPlateNum,
    List<Reservation>? newHistory,
  }) {
    if (newUsername != null) username = newUsername;
    if (newPassword != null) password = newPassword;
    if (newAddress != null) address = newAddress;
    if (newEmail != null) email = newEmail;
    if (newFullName != null) fullName = newFullName;
    if (newPlateNum != null) plateNum = newPlateNum;
    if (newHistory != null) history = newHistory;
  }

  factory Customer.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Customer.fromJson(data);
  }
}
