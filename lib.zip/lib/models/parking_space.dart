class ParkingSpace {
  final int parkingID;
  Map<String, bool> slotStatus;
  String storeName;
  int price;
  int totalAvailableSpace;
  int totalReservedSpace;
  int floor;

  ParkingSpace({
    required this.parkingID,
    required this.slotStatus,
    required this.storeName,
    required this.price,
    required this.totalAvailableSpace,
    required this.totalReservedSpace,
    required this.floor,
  });

  Map<String, dynamic> toJson() => {
        'parkingID': parkingID,
        'slotStatus': slotStatus,
        'storeName': storeName,
        'price': price,
        'totalAvailableSpace': totalAvailableSpace,
        'totalReservedSpace': totalReservedSpace,
        'floor': floor,
      };

  static ParkingSpace fromJson(Map<String, dynamic> json) {
    try {
      return ParkingSpace(
        parkingID: json['parkingID'] as int,
        slotStatus: Map<String, bool>.from(json['slotStatus'] ?? {}),
        storeName: json['storeName'] as String,
        price: json['price'] as int,
        totalAvailableSpace: json['totalAvailableSpace'] as int,
        totalReservedSpace: json['totalReservedSpace'] as int,
        floor: json['floor'] as int,
      );
    } catch (e) {
      throw Exception('Invalid ParkingSpace JSON format');
    }
  }
}
