class Reservation {
  final int userID;
  final String date;
  final String hourInfo;
  final int reservationID;
  final int totalHour;
  String slot;
  int totalPrice;
  String location;
  String status;

  Reservation({
    required this.userID,
    required this.date,
    required this.hourInfo,
    required this.totalHour,
    required this.reservationID,
    this.slot = "",
    this.totalPrice = 0,
    this.location = "",
    this.status = "Unfinished",
  });

  Map<String, dynamic> toJson() => {
        'userID': userID,
        'date': date,
        'hourInfo': hourInfo,
        'totalHour': totalHour,
        'reservationID': reservationID,
        'slot': slot,
        'totalPrice': totalPrice,
        'location': location,
        'status': status,
      };

  factory Reservation.fromMap(Map<String, dynamic> data) {
    return Reservation(
      userID: data['userID'],
      date: data['date'] ?? '',
      location: data['location'] ?? '',
      hourInfo: data['hourInfo'] ?? '',
      totalHour: data['totalHour'] ?? 0,
      slot: data['slot'] ?? '',
      totalPrice: (data['totalPrice'] ?? 0),
      reservationID: data['reservationID'] ?? 0,
    );
  }

  static Reservation fromJson(Map<String, dynamic> json) => Reservation(
        userID: json['userID'],
        date: json['date'],
        hourInfo: json['hourInfo'],
        totalHour: json['totalHour'],
        reservationID: json['reservationID'],
        slot: json['slot'],
        totalPrice: json['totalPrice'],
        location: json['location'],
        status: json['status'],
      );
}
