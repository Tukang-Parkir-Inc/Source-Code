import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/user.dart';

class Security extends User {
  final String address;
  final String email;
  final String fullName;
  final String departmentStore;

  Security({
    required int userID,
    required String username,
    required String password,
    required String role,
    required this.address,
    required this.email,
    required this.fullName,
    required this.departmentStore,
  }) : super(
          userID: userID,
          username: username,
          password: password,
          role: role,
        );

  @override
  Map<String, dynamic> toJson() {
    final userJson = super.toJson();
    return {
      ...userJson,
      'address': address,
      'email': email,
      'fullName': fullName,
      'departmentStore': departmentStore,
    };
  }

  Security fromJson(Map<String, dynamic> json) => Security(
        userID: json['userID'],
        username: json['username'],
        password: json['password'],
        role: json['role'],
        address: json['address'],
        email: json['email'],
        fullName: json['fullName'],
        departmentStore: json['departmentStore'],
      );

  factory Security.fromJson(Map<String, dynamic> json) {
    final userID = json['userID'] is int
        ? json['userID']
        : int.tryParse(json['userID'].toString()) ??
            0; // Safely handle int or String
    final username = json['username'] as String? ?? '';
    final password = json['password'] as String? ?? '';
    final role = json['role'] as String? ?? '';
    final address = json['address'] as String? ?? '';
    final fullName = json['fullName'] as String? ?? '';
    final departmentStore =
        json['departmentStore'].toString(); // Convert to String
    final email = json['email'] as String? ?? '';

    return Security(
      userID: userID,
      username: username,
      password: password,
      role: role,
      address: address,
      fullName: fullName,
      departmentStore: departmentStore,
      email: email,
    );
  }

  factory Security.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Security.fromJson(data);
  }
}
