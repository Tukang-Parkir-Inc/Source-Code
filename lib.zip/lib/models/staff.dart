import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/user.dart';

class Staff extends User {
  final String address;
  final String email;
  final String fullName;
  final String phoneNum;

  Staff({
    required int userID, // Changed to String
    required String username,
    required String password,
    required String role,
    required this.address,
    required this.email,
    required this.fullName,
    required this.phoneNum,
  }) : super(
          userID: userID,
          username: username,
          password: password,
          role: role,
        );

  @override
  Map<String, dynamic> toJson() {
    final userJson = super.toJson();
    return {
      ...userJson,
      'address': address,
      'email': email,
      'fullName': fullName,
      'phoneNum': phoneNum,
    };
  }

  Staff fromJson(Map<String, dynamic> json) => Staff(
        userID: json['userID'], // Ensure userID is a String
        username: json['username'],
        password: json['password'],
        role: json['role'],
        address: json['address'],
        email: json['email'],
        fullName: json['fullName'],
        phoneNum: json['phoneNum'],
      );

  factory Staff.fromJson(Map<String, dynamic> json) {
    final userID = json['userID'] is int
        ? json['userID']
        : int.tryParse(json['userID'].toString()) ??
            0; // Safely handle int or String
    final username = json['username'] as String? ?? '';
    final password = json['password'] as String? ?? '';
    final role = json['role'] as String? ?? '';
    final address = json['address'] as String? ?? '';
    final fullName = json['fullName'] as String? ?? '';
    final phoneNum = json['phoneNum'].toString(); // Convert to String
    final email = json['email'] as String? ?? '';

    return Staff(
      userID: userID,
      username: username,
      password: password,
      role: role,
      address: address,
      fullName: fullName,
      phoneNum: phoneNum,
      email: email,
    );
  }

  factory Staff.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Staff.fromJson(data);
  }
}
