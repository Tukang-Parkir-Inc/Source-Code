class User {
  final int userID;
  String username;
  String password;
  String role;

  User({
    required this.userID,
    required this.username,
    required this.password,
    required this.role,
  });

  // Convert User object to JSON
  Map<String, dynamic> toJson() {
    return {
      'userID': userID,
      'username': username,
      'password': password,
      'role': role,
    };
  }

  // Factory method to create a User instance from JSON
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      userID: json['userID'],
      username: json['username'],
      password: json['password'],
      role: json['role'],
    );
  }
}
