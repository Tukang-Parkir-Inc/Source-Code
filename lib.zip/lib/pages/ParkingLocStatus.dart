import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/parking_space.dart';
import 'package:try3/models/security.dart';
import 'package:try3/pages/ParkingStatusPage.dart';

class ParkingLocStatus extends StatefulWidget {
  final Security security;

  const ParkingLocStatus({
    required this.security,
    Key? key,
  }) : super(key: key);

  @override
  _ParkingLocStatusState createState() => _ParkingLocStatusState();
}

class _ParkingLocStatusState extends State<ParkingLocStatus> {
  ParkingSpace? parkingSpace;
  String selectedSlot = ""; // Selected slot
  int currentFloor = 1; // Start at the first floor
  bool isLoading = true; // Track loading state

  @override
  void initState() {
    super.initState();
    _fetchParkingSpaceForSecurity();
  }

  Future<void> _fetchParkingSpaceForSecurity() async {
    try {
      final securityDoc = await FirebaseFirestore.instance
          .collection('Security Personnel')
          .doc(widget.security.userID.toString())
          .get();

      if (!securityDoc.exists)
        throw Exception('Security personnel record not found.');

      final securityData = securityDoc.data();
      if (securityData == null || securityData['departmentStore'] == null) {
        throw ArgumentError(
            'departmentStore field is missing in Security record.');
      }

      final departmentStore = securityData['departmentStore'];
      await _fetchParkingSpace(departmentStore);
    } catch (e) {
      print('Error fetching parking space data for security: $e');
      setState(() => isLoading = false);
    }
  }

  Future<void> _fetchParkingSpace(String departmentStore) async {
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('Parking Space')
          .where('storeName', isEqualTo: departmentStore)
          .limit(1)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        final data = querySnapshot.docs.first.data();
        setState(() {
          parkingSpace = ParkingSpace.fromJson(data);
          isLoading = false;
        });
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      print('Error fetching parking space data: $e');
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (parkingSpace == null) {
      return Scaffold(
        body: Center(
            child: Text('No parking space available for this location.')),
      );
    }

    final totalSlots =
        parkingSpace!.totalAvailableSpace + parkingSpace!.totalReservedSpace;
    final totalFloors = parkingSpace!.floor;
    final slots = parkingSpace!.slotStatus.entries.toList();
    final startIndex = (currentFloor - 1) * 15;
    final endIndex =
        startIndex + 15 > slots.length ? slots.length : startIndex + 15;

    final availableSlots = slots.sublist(startIndex, endIndex);

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(totalSlots, totalFloors),
            _buildLegendSection(),
            _buildSlotGrid(availableSlots),
            _buildReserveButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(int totalSlots, int totalFloors) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF00A9E0),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      parkingSpace!.storeName,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      "${totalSlots} total slots",
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(Icons.arrow_left, color: Colors.white),
                  onPressed: currentFloor > 1
                      ? () => setState(() => currentFloor--)
                      : null,
                ),
                Text(
                  "Floor $currentFloor",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.arrow_right, color: Colors.white),
                  onPressed: currentFloor < totalFloors
                      ? () => setState(() => currentFloor++)
                      : null,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegendSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildLegend("Booked", Colors.red),
          _buildLegend("Available", Colors.grey),
          _buildLegend("Your choice", Colors.yellow),
        ],
      ),
    );
  }

  Widget _buildSlotGrid(List<MapEntry<String, bool>> availableSlots) {
    return Expanded(
      child: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemCount: availableSlots.length,
        itemBuilder: (context, index) {
          final slotEntry = availableSlots[index];
          final slot = slotEntry.key;
          final isAvailable = slotEntry.value;
          final isSelected = selectedSlot == slot;

          return GestureDetector(
            onTap: () => setState(() => selectedSlot = slot),
            child: Container(
              decoration: BoxDecoration(
                color: !isAvailable
                    ? (isSelected ? Colors.yellow : Colors.red)
                    : (isSelected ? Colors.yellow : Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: Text(
                  slot,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildReserveButton() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ElevatedButton(
        onPressed: selectedSlot.isEmpty
            ? null
            : () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ParkingStatusPage(
                      security: widget.security,
                      slot: selectedSlot,
                      parkingSpace: parkingSpace!,
                    ),
                  ),
                ),
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0xFF00A9E0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        child: Text(
          "Check",
          style: TextStyle(color: Colors.white, fontSize: 25),
        ),
      ),
    );
  }

  Widget _buildLegend(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        SizedBox(width: 8),
        Text(label, style: TextStyle(fontSize: 14)),
      ],
    );
  }
}
