import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/parking_space.dart';
import 'package:try3/models/security.dart';
import 'package:try3/pages/securityDashboard.dart';

class ParkingStatusPage extends StatefulWidget {
  final Security security;
  final String slot;
  final ParkingSpace parkingSpace;

  const ParkingStatusPage({
    required this.security,
    required this.slot,
    required this.parkingSpace,
    Key? key,
  }) : super(key: key);

  @override
  _ParkingStatusPageState createState() => _ParkingStatusPageState();
}

class _ParkingStatusPageState extends State<ParkingStatusPage> {
  late bool isAvailable;
  final TextEditingController timeController = TextEditingController();
  String? timeError;
  late bool initialAvailability;
  bool isUpdating = false; // Prevent multiple updates

  @override
  void initState() {
    super.initState();
    // Initialize isAvailable based on the slot status
    isAvailable = widget.parkingSpace.slotStatus[widget.slot] ?? false;
    initialAvailability = isAvailable;
  }

  Future<void> _fetchAndUpdateSlotAvailability(bool availability) async {
    if (isUpdating) return; // Prevent concurrent updates

    try {
      setState(() {
        isUpdating = true;
      });

      // Fetch the latest parking space data using storeName
      final querySnapshot = await FirebaseFirestore.instance
          .collection('Parking Space')
          .where('storeName', isEqualTo: widget.parkingSpace.storeName)
          .limit(1)
          .get();

      if (querySnapshot.docs.isEmpty) {
        throw Exception(
            'Parking space not found for store: ${widget.parkingSpace.storeName}');
      }

      final parkingSpaceData = querySnapshot.docs.first.data();

      // Update slot status and calculate changes
      final updatedSlotStatus =
          Map<String, bool>.from(parkingSpaceData['slotStatus'] ?? {});
      updatedSlotStatus[widget.slot] = availability;

      final int totalAvailableSpace =
          parkingSpaceData['totalAvailableSpace'] ?? 0;
      final int totalReservedSpace =
          parkingSpaceData['totalReservedSpace'] ?? 0;

      final int availableChange = availability ? 1 : -1;
      final int reservedChange = availability ? -1 : 1;

      // Update Firestore document
      await FirebaseFirestore.instance
          .collection('Parking Space')
          .doc(querySnapshot.docs.first.id)
          .update({
        'slotStatus': updatedSlotStatus,
        'totalAvailableSpace': totalAvailableSpace + availableChange,
        'totalReservedSpace': totalReservedSpace + reservedChange,
      });

      // Update UI state
      setState(() {
        isAvailable = availability;
        widget.parkingSpace.slotStatus = updatedSlotStatus;
        widget.parkingSpace.totalAvailableSpace += availableChange;
        widget.parkingSpace.totalReservedSpace += reservedChange;
      });

      print(
          'Slot ${widget.slot} updated to ${availability ? "available" : "reserved"}');
    } catch (e) {
      print('Error updating slot availability: $e');
    } finally {
      setState(() {
        isUpdating = false;
      });
    }
  }

  bool _validateTime(String time) {
    final timeParts = time.split(":");
    if (timeParts.length != 2) return false;
    final hours = int.tryParse(timeParts[0]);
    final minutes = int.tryParse(timeParts[1]);
    if (hours == null || minutes == null) return false;
    return hours >= 0 && hours <= 24 && minutes >= 0 && minutes <= 59;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Clouds Image
          Positioned.fill(
            child: Image.asset(
              'lib/images/Clouds.png',
              fit: BoxFit.cover,
            ),
          ),

          // Buildings at the Bottom
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              'lib/images/Group 19.png',
              fit: BoxFit.cover,
              height: 120,
            ),
          ),

          // Content
          Column(
            children: [
              SizedBox(height: 40),

              // AppBar with Back Button
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                    Spacer(),
                  ],
                ),
              ),

              // Title
              Text(
                widget.parkingSpace.storeName,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),

              Spacer(),

              // White Curved Rectangle
              Container(
                margin: EdgeInsets.symmetric(horizontal: 16.0),
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16.0),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 10,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Availability Toggle
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Available",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        Row(
                          children: [
                            Text(
                              "No",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.red,
                              ),
                            ),
                            Switch(
                              value: isAvailable,
                              onChanged: (value) {
                                if (!isUpdating && value != isAvailable) {
                                  _fetchAndUpdateSlotAvailability(value);
                                }
                              },
                              activeColor: Colors.green,
                              inactiveThumbColor: Colors.red,
                              inactiveTrackColor: Colors.red.withOpacity(0.4),
                            ),
                            Text(
                              "Yes",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.green,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),

                    SizedBox(height: 16),

                    // Time Updated Input
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Time Updated",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                        Container(
                          width: 100,
                          child: TextField(
                            controller: timeController,
                            decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: "HH:MM",
                              errorText: timeError,
                            ),
                            keyboardType: TextInputType.datetime,
                            style: TextStyle(color: Colors.black),
                            onChanged: (value) {
                              setState(() {
                                timeError = _validateTime(value)
                                    ? null
                                    : "Invalid time";
                              });
                            },
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 24),

                    // Save Changes Button
                    ElevatedButton(
                      onPressed: () {
                        if (timeError == null &&
                            _validateTime(timeController.text)) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  securityDashboard(security: widget.security),
                            ),
                          );
                        } else {
                          setState(() {
                            timeError = "Please enter a valid time";
                          });
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        minimumSize: Size(double.infinity, 48),
                      ),
                      child: Text(
                        "Save Changes",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              Spacer(),
            ],
          ),
        ],
      ),
    );
  }
}
