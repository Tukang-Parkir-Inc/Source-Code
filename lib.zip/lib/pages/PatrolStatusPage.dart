import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/security.dart';
import 'package:try3/models/parking_space.dart';

class PatrolStatusPage extends StatefulWidget {
  final Security security;

  const PatrolStatusPage({
    required this.security,
    Key? key,
  }) : super(key: key);

  @override
  _PatrolStatusPageState createState() => _PatrolStatusPageState();
}

class _PatrolStatusPageState extends State<PatrolStatusPage> {
  ParkingSpace? parkingSpace;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchParkingSpace();
  }

  Future<void> _fetchParkingSpace() async {
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('Parking Space')
          .where('storeName', isEqualTo: widget.security.departmentStore)
          .limit(1)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        final data = querySnapshot.docs.first.data();
        setState(() {
          parkingSpace = ParkingSpace.fromJson(data);
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
        print(
            'No parking space found for department store: ${widget.security.departmentStore}');
      }
    } catch (e) {
      print('Error fetching parking space data: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (parkingSpace == null) {
      return Scaffold(
        body: Center(
          child: Text(
              'No parking space data available for this department store.'),
        ),
      );
    }

    final availableSlots = parkingSpace!.slotStatus.entries
        .where((entry) => entry.value)
        .map((entry) => entry.key)
        .toList();

    final bookedSlots = parkingSpace!.slotStatus.entries
        .where((entry) => !entry.value)
        .map((entry) => entry.key)
        .toList();

    return Scaffold(
      body: Stack(
        children: [
          // Background with Clouds.png
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('lib/images/Clouds.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Back button and header
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                  Spacer(),
                  Text(
                    widget.security.departmentStore,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontFamily: 'Poppins',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  Spacer(flex: 2),
                ],
              ),
            ),
          ),
          // Curved white rectangle
          Column(
            children: [
              Spacer(),
              Container(
                height: MediaQuery.of(context).size.height * 0.8,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20.0),
                    topRight: Radius.circular(20.0),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black,
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Available Section
                    Expanded(
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8.0),
                            decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              'Available ${availableSlots.length}',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                          Expanded(
                            child: ListView.builder(
                              itemCount: availableSlots.length,
                              itemBuilder: (context, index) {
                                return _buildStatusRow(
                                  availableSlots[index],
                                  'Available',
                                  true,
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Booked Section
                    Expanded(
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8.0),
                            decoration: BoxDecoration(
                              color: Colors.red[100],
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              'Booked ${bookedSlots.length}',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.red,
                                fontFamily: 'Poppins',
                              ),
                            ),
                          ),
                          Expanded(
                            child: ListView.builder(
                              itemCount: bookedSlots.length,
                              itemBuilder: (context, index) {
                                return _buildStatusRow(
                                  bookedSlots[index],
                                  'Booked',
                                  false,
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusRow(String code, String time, bool isAvailable) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                isAvailable ? Icons.check_circle : Icons.cancel,
                color: isAvailable ? Colors.green : Colors.red,
              ),
              SizedBox(width: 8),
              Text(
                code,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Poppins',
                ),
              ),
            ],
          ),
          Text(
            time,
            style: TextStyle(
              fontSize: 14,
              color: Colors.black,
              fontFamily: 'Poppins',
            ),
          ),
        ],
      ),
    );
  }
}
