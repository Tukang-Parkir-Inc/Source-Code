import 'package:flutter/material.dart';

class UserDataPage extends StatelessWidget {
  final String name;
  final String email;
  final String username;
  final String password;
  final String address;
  final String plateNumber;

  UserDataPage({
    required this.name,
    required this.email,
    required this.username,
    required this.password,
    required this.address,
    required this.plateNumber,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Clouds Image
          Positioned.fill(
            child: Image.asset(
              'lib/Clouds.png',
              fit: BoxFit.cover,
            ),
          ),

          Column(
            children: [
              // AppBar
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 16.0, horizontal: 8.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.blue),
                      onPressed: () {
                        Navigator.pop(context); // Go back to the previous page
                      },
                    ),
                    Text(
                      "Profile",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              // Profile Picture
              CircleAvatar(
                radius: 50, // Bigger size for the profile picture
                backgroundImage:
                    AssetImage('lib/profile.png'), // Placeholder image
              ),
              SizedBox(height: 8),
              Text(
                name,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),

              SizedBox(height: 16),

              // User Information Table
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                  ),
                  child: Column(
                    children: [
                      buildInfoRow("Email", email),
                      buildInfoRow("Full Name", name),
                      buildInfoRow("Username", username),
                      buildInfoRow("Password", password),
                      buildInfoRow("Address", address),
                      buildInfoRow("Plate Number", plateNumber),
                      Spacer(),
                      // Delete Button
                      ElevatedButton(
                        onPressed: () {
                          // Action for delete
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          padding: EdgeInsets.symmetric(
                              horizontal: 32, vertical: 12),
                        ),
                        child: Text(
                          "Delete",
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                      SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Helper Widget for Info Rows
  Widget buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 16, color: Colors.black54),
          ),
          Text(
            value,
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
          ),
        ],
      ),
    );
  }
}
