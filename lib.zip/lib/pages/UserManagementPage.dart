import 'package:flutter/material.dart';
import 'UserDataPage.dart';

class UserManagementPage extends StatefulWidget {
  @override
  _UserManagementPageState createState() => _UserManagementPageState();
}

class _UserManagementPageState extends State<UserManagementPage> {
  // Dummy user data
  final List<Map<String, dynamic>> users = [
    {'name': 'Jauza Zahra', 'role': 'Customer'},
    {'name': 'Ebrahim Nakhwa', 'role': 'Admin'},
    {'name': 'Grizelda Audria', 'role': 'Customer'},
    {'name': 'Akmal', 'role': 'Security'},
  ];

  final List<String> roles = ['Customer', 'Security', 'Admin'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Clouds Image
          Positioned.fill(
            child: Image.asset(
              'lib/Clouds.png',
              fit: BoxFit.cover,
            ),
          ),

          Column(
            children: [
              // AppBar
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 16.0, horizontal: 8.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () {
                        Navigator.pop(context); // Go back to the dashboard
                      },
                    ),
                    Text(
                      "Dashboard",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              // Title
              Text(
                "Manage Users",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),

              SizedBox(height: 16),

              // User List
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16),
                      topRight: Radius.circular(16),
                    ),
                  ),
                  child: ListView.builder(
                    itemCount: users.length,
                    itemBuilder: (context, index) {
                      final user = users[index];
                      return Card(
                        color: Colors.white,
                        margin:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              CircleAvatar(
                                backgroundImage: AssetImage(
                                    'lib/profile.png'), // Placeholder image
                                radius: 24,
                              ),
                              SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      user['name'],
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.teal),
                                    ),
                                    Text(
                                      "User Role: ${user['role']}",
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                children: [
                                  ElevatedButton(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => UserDataPage(
                                            name: user['name'],
                                            email:
                                                "${user['name'].toLowerCase().replaceAll(' ', '')}@gmail.com", // Example email
                                            username: user['name']
                                                .toLowerCase()
                                                .replaceAll(' ',
                                                    ''), // Example username
                                            password:
                                                "pass1234", // Example password
                                            address:
                                                "Bandung", // Example address
                                            plateNumber:
                                                "D 7162 CA", // Example plate number
                                          ),
                                        ),
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue,
                                      minimumSize: Size(100, 36),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            8), // Adjust the radius here
                                      ),
                                    ),
                                    child: Text("User Data",
                                        style: TextStyle(color: Colors.white)),
                                  ),
                                  PopupMenuButton<String>(
                                    onSelected: (value) {
                                      setState(() {
                                        user['role'] = value;
                                      });
                                    },
                                    itemBuilder: (context) {
                                      return roles.map((role) {
                                        return PopupMenuItem<String>(
                                          value: role,
                                          child: Text(role,
                                              style: TextStyle(
                                                color: Colors
                                                    .white, // Change this if needed
                                              )),
                                        );
                                      }).toList();
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Colors.blue,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      padding: EdgeInsets.symmetric(
                                          vertical: 8, horizontal: 16),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            "Change role",
                                            style:
                                                TextStyle(color: Colors.white),
                                          ),
                                          Icon(
                                            Icons.arrow_drop_down,
                                            color: Colors.white,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),

          // Buildings Image
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              'lib/Group 19.png',
              fit: BoxFit.cover,
              height: 100,
            ),
          ),
        ],
      ),
    );
  }
}
