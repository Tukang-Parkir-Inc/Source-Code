import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/parking_space.dart';
import 'package:try3/models/reservation.dart';
import 'payment.dart';

class ChooseLoc extends StatefulWidget {
  final ParkingSpace parkingSpace; // Parking space details
  final Reservation reservation; // Reservation details
  final Customer customer;

  const ChooseLoc({
    required this.customer,
    required this.parkingSpace,
    required this.reservation,
    Key? key,
  }) : super(key: key);

  @override
  _ChooseLocState createState() => _ChooseLocState();
}

class _ChooseLocState extends State<ChooseLoc> {
  ParkingSpace? parkingSpace;
  String selectedSlot = ""; // To store the selected slot
  int currentFloor = 1; // Start at the first floor

  bool isLoading = true;

  Future<void> _fetchParkingData() async {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('Parking Space')
          .doc(widget.parkingSpace.parkingID.toString())
          .get();

      if (doc.exists && doc.data() != null) {
        final data = doc.data()!;
        print('Fetched data: $data');

        setState(() {
          parkingSpace = ParkingSpace.fromJson(data);
        });
      } else {
        print('Document does not exist or is empty');
        setState(() {
          parkingSpace = null;
        });
      }
    } catch (e) {
      print('Error fetching parking space data: $e');
      setState(() {
        parkingSpace = null;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchParkingData(); // Fetch parking data on widget initialization
  }

  @override
  Widget build(BuildContext context) {
    final slots = widget.parkingSpace.slotStatus.entries.toList();
    final totalSlots = widget.parkingSpace.totalAvailableSpace +
        widget.parkingSpace.totalReservedSpace;
    final totalFloors = widget.parkingSpace.floor;

// Calculate start and end index for the current floor
    final startIndex = (currentFloor - 1) * 15;
    final endIndex =
        startIndex + 15 > slots.length ? slots.length : startIndex + 15;

// Get slots for the current floor
    final availableSlots = slots.sublist(startIndex, endIndex);

    print("Total Floors: $totalFloors");
    print("Current Floor: $currentFloor");
    print("Start Index: $startIndex");
    print("End Index: $endIndex");
    print("Total Slots: ${slots.length}");
    print("Available Slots for Floor $currentFloor: $availableSlots");

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Header Section
            Container(
              decoration: const BoxDecoration(
                color: Color(0xFF00A9E0),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16.0, vertical: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon:
                              const Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () {
                            Navigator.pop(context); // Go back
                          },
                        ),
                        const SizedBox(width: 8),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.parkingSpace.storeName,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "${widget.reservation.date}  |  ${widget.reservation.hourInfo}",
                              style: const TextStyle(
                                  fontSize: 14, color: Colors.white70),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      "Choose Slot",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          icon:
                              const Icon(Icons.arrow_left, color: Colors.white),
                          onPressed: currentFloor > 1
                              ? () {
                                  setState(() {
                                    currentFloor--;
                                  });
                                }
                              : null, // Disable if already on the first floor
                        ),
                        Text(
                          "Floor $currentFloor",
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.arrow_right,
                              color: Colors.white),
                          onPressed: currentFloor < totalFloors
                              ? () {
                                  setState(() {
                                    currentFloor++;
                                  });
                                }
                              : null, // Disable if already on the last floor
                        ),
                      ],
                    ),
                    Center(
                      child: Text(
                        "${widget.parkingSpace.totalAvailableSpace} slots available",
                        style: const TextStyle(
                          fontSize: 18,
                          color: Colors.redAccent,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Legend Section
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildLegend("Booked", Colors.red),
                  _buildLegend("Available", Colors.grey),
                  _buildLegend("Your choice", Colors.yellow),
                ],
              ),
            ),

            // Slot Grid Section
            Expanded(
              child: availableSlots.isNotEmpty
                  ? GridView.builder(
                      padding: const EdgeInsets.all(16),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                      ),
                      itemCount: availableSlots.length,
                      itemBuilder: (context, index) {
                        // Sort availableSlots by slot name (A1, B2, etc.)
                        final sortedSlots = availableSlots.toList()
                          ..sort((a, b) {
                            final regex = RegExp(r'([A-Z])(\d+)');
                            final matchA = regex.firstMatch(a.key);
                            final matchB = regex.firstMatch(b.key);

                            if (matchA != null && matchB != null) {
                              final letterA =
                                  matchA.group(1)!; // Letter part (A, B, ...)
                              final letterB = matchB.group(1)!;
                              final numberA =
                                  int.parse(matchA.group(2)!); // Number part
                              final numberB = int.parse(matchB.group(2)!);

                              // First, sort by letters (A-H), then by numbers (1-5)
                              if (letterA == letterB) {
                                return numberA.compareTo(numberB);
                              }
                              return letterA.compareTo(letterB);
                            }
                            return a.key.compareTo(b.key);
                          });

                        final slotEntry = sortedSlots[index];
                        final slot =
                            slotEntry.key; // Slot name (e.g., A1, B2, etc.)
                        final isAvailable =
                            slotEntry.value; // Availability (true/false)
                        final isSelected = selectedSlot == slot;

                        return GestureDetector(
                          onTap: isAvailable
                              ? () {
                                  setState(() {
                                    selectedSlot = slot;
                                  });
                                }
                              : null,
                          child: Container(
                            decoration: BoxDecoration(
                              color: !isAvailable
                                  ? Colors.red
                                  : isSelected
                                      ? Colors.yellow
                                      : Colors.grey,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Center(
                              child: Text(
                                slot,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    )
                  : const Center(
                      child: Text("No slots available for this floor"),
                    ),
            ),

            // Reserve Button
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: selectedSlot.isEmpty
                    ? null
                    : () {
                        setState(() {
                          widget.reservation.slot =
                              selectedSlot; // Update the reservation slot
                        });
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PaymentPage(
                                customer:
                                    widget.customer, // Pass the Customer object
                                parkingSpace: widget
                                    .parkingSpace, // Pass the ParkingSpace object
                                reservation: widget.reservation),
                          ),
                        );
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF00A9E0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  "Reserve",
                  style: TextStyle(color: Colors.white, fontSize: 25),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegend(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 8),
        Text(label, style: const TextStyle(fontSize: 14)),
      ],
    );
  }
}

int getFloorFromSlot(String slotName) {
  // Assuming slot names include "FL" followed by floor number (e.g., FL1A1, FL2B1)
  final regex = RegExp(r'FL(\d+)');
  final match = regex.firstMatch(slotName);
  return match != null ? int.parse(match.group(1)!) : 1;
}
