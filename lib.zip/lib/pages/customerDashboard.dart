import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/reservation.dart';
import 'reservationPage.dart';
import 'profile.dart';
import 'history.dart';

class customerDashboard extends StatefulWidget {
  final Customer customer;

  const customerDashboard({required this.customer, Key? key}) : super(key: key);

  @override
  _CustomerDashboardState createState() => _CustomerDashboardState();
}

class _CustomerDashboardState extends State<customerDashboard> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  int _selectedIndex = 0;
  List<Reservation> reservationHistory = [];
  bool isLoading = true;

  Future<void> fetchReservationHistory(int userID) async {
    print("Fetching reservation history for userID: $userID");

    try {
      // Query Firestore to fetch the reservations for the user
      QuerySnapshot reservationQuery = await FirebaseFirestore.instance
          .collection('Reservation')
          .where('userID', isEqualTo: userID) // Filter by userID
          .get();

      // Check if any reservations were found
      if (reservationQuery.docs.isEmpty) {
        print("No reservations found for userID: $userID");
      } else {
        print("Fetched Reservations: ${reservationQuery.docs.length}");
      }

      List<Reservation> fetchedReservations = reservationQuery.docs.map((doc) {
        return Reservation.fromMap(doc.data() as Map<String, dynamic>);
      }).toList();

      // Sort by date in descending order (most recent first)
      fetchedReservations.sort((a, b) {
        return b.date.compareTo(
            a.date); // Ensure 'date' is a DateTime or comparable string
      });

      setState(() {
        reservationHistory = fetchedReservations;
        isLoading = false;
      });
    } catch (e) {
      print("Error fetching reservation history: $e");
      setState(() {
        isLoading = false;
      });
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        // Navigate to Home screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => customerDashboard(customer: widget.customer),
          ),
        );
        break;
      case 1:
        // Navigate to Reserve screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => reservationPage(customer: widget.customer),
          ),
        );
        break;
      case 2:
        // Navigate to Profile screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Profile(customer: widget.customer),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    // Start by calling the fetch function if necessary
    if (isLoading) {
      fetchReservationHistory(widget.customer.userID);
    }
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                image: const DecorationImage(
                  image: AssetImage("lib/images/bg.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Hi, where are you going today?',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        CircleAvatar(
                          radius: 18,
                          backgroundImage: AssetImage(
                              "lib/images/billie.jpg"), // Corrected usage
                        ),
                      ],
                    ),
                  ),
                  // Ongoing reservation card
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Container(
                      width: double.infinity,
                      height: 130,
                      decoration: BoxDecoration(
                        color: Color(0xFF54BBE6),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Left side with icons and text
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 15.0, top: 10.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Text(
                                  'On Going Reservation',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16,
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),

                                SizedBox(height: 10), // Adjust spacing
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment
                                      .start, // Align items to the start
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.calendar_today,
                                          color: Colors.black,
                                          size: 16,
                                        ),
                                        SizedBox(
                                            width:
                                                8), // Add space between the icon and text
                                        Text(
                                          reservationHistory.isNotEmpty
                                              ? reservationHistory[0]
                                                  .date // The most recent reservation's date
                                              : 'No reservation', // If no reservation exists
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 14,
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 10), // Space between rows
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.directions_car,
                                          color: Colors.black,
                                          size: 16,
                                        ),
                                        SizedBox(
                                            width:
                                                8), // Add space between the icon and text
                                        Text(
                                          reservationHistory.isNotEmpty
                                              ? reservationHistory[0]
                                                  .hourInfo // The most recent reservation's hourInfo
                                              : 'No reservation', // If no reservation exists
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 14,
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 10), // Space between rows
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.location_on,
                                          color: Colors.black,
                                          size: 16,
                                        ),
                                        SizedBox(
                                            width:
                                                8), // Add space between the icon and text
                                        Text(
                                          reservationHistory.isNotEmpty
                                              ? reservationHistory[0]
                                                  .location // The most recent reservation's location
                                              : 'No reservation', // If no reservation exists
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 14,
                                            fontFamily: 'Poppins',
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                          // Right side with logo image
                          Padding(
                            padding:
                                const EdgeInsets.all(10.0), // Reduce padding
                            child: Image.asset(
                              "lib/images/Group 21.png",
                              width: 120, // Adjust width to fit
                              height: 120, // Adjust height to fit
                              fit: BoxFit.contain,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  // Buttons for Reserve, History, Profile
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildIconButton(
                          'Reserve',
                          Color(0xFF54BBE6),
                          'lib/images/Vector.png',
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => reservationPage(
                                      customer: widget.customer)),
                            );
                          },
                        ),
                        _buildIconButton(
                          'History',
                          Color(0xFF54BBE6),
                          'lib/images/Group.png',
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      History(customer: widget.customer)),
                            );
                          },
                        ),
                        _buildIconButton(
                          'Profile',
                          Color(0xFF54BBE6),
                          'lib/images/Group (1).png',
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      Profile(customer: widget.customer)),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Spacer(),
                  // Overlapping Group 19 and Group 14
                  Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.25,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("lib/images/Group 19.png"),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: 68,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("lib/images/Group 14.png"),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFF54BBE6),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped, // Handle taps
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.car_rental),
            label: 'Reserve',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_box),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildIconButton(
      String label, Color color, String imagePath, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap, // This is where the action is triggered
      child: Column(
        children: [
          Container(
            width: 63,
            height: 47,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Center(
              child: Image.asset(
                imagePath,
                width: 24, // Adjust width if needed
                height: 24, // Adjust height if needed
                fit: BoxFit.contain,
              ),
            ),
          ),
          SizedBox(height: 5),
          Text(
            label.replaceAll(' ', '\n'),
            style: TextStyle(
              color: Colors.black,
              fontSize: 14,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }
}
