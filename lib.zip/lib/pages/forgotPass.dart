import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/user.dart';
import 'login.dart';
import 'customerDashboard.dart';

class Forgotpass extends StatefulWidget {
  final String username; // Accept username from the login page

  Forgotpass({required this.username});

  @override
  _ForgotpassState createState() => _ForgotpassState();
}

class _ForgotpassState extends State<Forgotpass> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _verification1Controller =
      TextEditingController();
  final TextEditingController _verification2Controller =
      TextEditingController();
  final TextEditingController _verification3Controller =
      TextEditingController();
  final TextEditingController _verification4Controller =
      TextEditingController();

  bool _isButtonEnabled = false;
  bool _isSendCodeButtonEnabled = true;
  bool _isCodeSent = false;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    _verification1Controller.addListener(_validateFields);
    _verification2Controller.addListener(_validateFields);
    _verification3Controller.addListener(_validateFields);
    _verification4Controller.addListener(_validateFields);
  }

  void _validateFields() {
    setState(() {
      _isButtonEnabled = _verification1Controller.text.isNotEmpty &&
          _verification2Controller.text.isNotEmpty &&
          _verification3Controller.text.isNotEmpty &&
          _verification4Controller.text.isNotEmpty;
    });
  }

  Future<void> _sendVerificationCode() async {
    String username = _usernameController.text.trim();

    if (username.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter a username.')),
      );
      return;
    }

    try {
      QuerySnapshot userSnapshot = await _firestore
          .collection('User')
          .where('username', isEqualTo: username)
          .get();

      if (userSnapshot.docs.isNotEmpty) {
        setState(() {
          _isCodeSent = true;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Verification code sent to your email.')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('No account found for the provided username.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('An error occurred: $e')),
      );
    }
  }

  Future<Customer?> _fetchCustomer(String username) async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('Customer')
          .where('username', isEqualTo: username)
          .get();

      if (snapshot.docs.isNotEmpty) {
        DocumentSnapshot customerDoc = snapshot.docs.first;
        var customerData = customerDoc.data();

        if (customerData != null && customerData is Map<String, dynamic>) {
          return Customer.fromJson(customerData);
        }
      }
    } catch (e) {
      print('Error fetching customer data: $e');
    }
    return null;
  }

  Future<void> _verifyCode() async {
    String verificationCode = _verification1Controller.text +
        _verification2Controller.text +
        _verification3Controller.text +
        _verification4Controller.text;

    if (verificationCode.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter the verification code.')),
      );
      return;
    }

    if (verificationCode == '1234') {
      // Replace with actual validation logic
      String username = _usernameController.text.trim();
      Customer? customer = await _fetchCustomer(username);

      if (customer != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => customerDashboard(customer: customer),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to find customer data.')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Invalid verification code.')),
      );
    }
  }

  Widget _buildCodeInput(TextEditingController controller) {
    return Container(
      width: 45,
      height: 45,
      child: TextField(
        controller: controller,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: Colors.black,
          fontSize: 16,
        ),
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        keyboardType: TextInputType.number,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          image: DecorationImage(
            image: AssetImage("lib/images/Sign Up.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Back button and title
                Row(
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => login()),
                      ),
                    ),
                    SizedBox(width: 16),
                    Text(
                      'Forgot Password',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment
                        .center, // Center all widgets vertically
                    crossAxisAlignment: CrossAxisAlignment
                        .center, // Center all widgets horizontally
                    children: [
                      Text(
                        'Verification',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 60),
                      // Subtitle
                      // Username Input Section
                      Center(
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: TextField(
                                    controller: _usernameController,
                                    decoration: InputDecoration(
                                      labelText: 'Username',
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                                SizedBox(width: 8),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                        Color(0xFF278EA5), // Background color
                                  ),
                                  onPressed: _isSendCodeButtonEnabled
                                      ? _sendVerificationCode
                                      : null,
                                  child: Text(
                                    'Send Code',
                                    style: TextStyle(
                                        color: Colors
                                            .white), // Fixed Color.white to Colors.white
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 20),
                            if (_isCodeSent)
                              Column(
                                children: [
                                  Text(
                                    'Enter Verification Code',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 22,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 20),
                                  // Asset Image
                                  Container(
                                    width: 100,
                                    height: 100,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(
                                            'lib/images/mail.png'), // Add your asset path here
                                        fit: BoxFit.contain,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20),
                                  // Description
                                  Text(
                                    'We sent you a verification code to your email.',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w400,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  Text(
                                    'You have 5 attempts.',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w400,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                  SizedBox(height: 60),

                                  Text(
                                    'Verification Code',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w400,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),

                                  SizedBox(height: 20),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      _buildCodeInput(_verification1Controller),
                                      SizedBox(width: 10),
                                      _buildCodeInput(_verification2Controller),
                                      SizedBox(width: 10),
                                      _buildCodeInput(_verification3Controller),
                                      SizedBox(width: 10),
                                      _buildCodeInput(_verification4Controller),
                                    ],
                                  ),
                                  SizedBox(height: 120),
// Continue Button
                                  Center(
                                    child: ElevatedButton(
                                      onPressed:
                                          _isButtonEnabled ? _verifyCode : null,
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: _isButtonEnabled
                                            ? Color(0xFF278EA5)
                                            : Colors.grey,
                                        fixedSize: Size(screenWidth * 0.8, 50),
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          side: BorderSide(
                                            color:
                                                Colors.black.withOpacity(0.67),
                                            width: 1,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        'Continue',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 16,
                                          fontFamily: 'Poppins',
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ),

                                  SizedBox(height: 20),
// Resend Code
                                  GestureDetector(
                                    onTap: () {
                                      // Add your resend code logic here
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content: Text(
                                                'Resend code action triggered.')),
                                      );
                                    },
                                    child: Text(
                                      'Resend Code',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 13,
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w400,
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget _buildCodeInput(TextEditingController controller) {
  return Container(
    width: 45,
    height: 45,
    child: TextField(
      controller: controller,
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Colors.black, // Set the text color to black
        fontSize: 16, // Optional: Adjust font size if needed
      ),
      decoration: InputDecoration(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        contentPadding: EdgeInsets.zero,
      ),
      keyboardType: TextInputType.number,
    ),
  );
}
