import 'package:flutter/material.dart';
import 'login.dart';

class LoadingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Get screen dimensions
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      body: GestureDetector(
        onTap: () {
          // Navigate to the LogIn page
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => login()),
          );
        },
        child: Container(
          width: screenWidth, // Use screen width
          height: screenHeight, // Use screen height
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage("lib/images/Clouds.png"),
              fit: BoxFit.cover, // Ensures the image covers the container
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                // Adjust relative to screen width
                top: screenHeight * 0.4, // Adjust relative to screen height
                child: Container(
                  width: screenWidth * 0.9, // 80% of screen width
                  height: screenHeight * 0.2, // 20% of screen height
                  decoration: BoxDecoration(
                    image: const DecorationImage(
                      image: AssetImage("lib/images/Group 21.png"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
