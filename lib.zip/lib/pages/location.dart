import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/parking_space.dart';
import 'package:try3/models/reservation.dart';
import 'package:try3/pages/chooseLoc.dart';
import 'package:try3/pages/reservationPage.dart';

class ReservationLoc extends StatelessWidget {
  final Reservation reservation;
  final Customer customer;

  const ReservationLoc({
    required this.reservation,
    required this.customer,
    Key? key,
  }) : super(key: key);

  Future<List<ParkingSpace>> _fetchParkingSpaces() async {
    try {
      final querySnapshot =
          await FirebaseFirestore.instance.collection('Parking Space').get();
      final data = querySnapshot.docs.map((doc) {
        print("Document Data: ${doc.data()}");
        return ParkingSpace.fromJson(doc.data());
      }).toList();
      return data;
    } catch (e) {
      print("Error fetching parking spaces: $e");
      rethrow;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('lib/images/History.png'), // Background image
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            // First Section: Back button and "Choose Your Location" text
            Padding(
              padding: const EdgeInsets.only(top: 50, left: 16, right: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () {
                          Navigator.pop(context); // Navigate back
                        },
                      ),
                      SizedBox(width: 4),
                      Text(
                        "Location",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(width: 13),
                      Icon(Icons.calendar_today, color: Colors.white, size: 16),
                      SizedBox(width: 3),
                      Text(
                        reservation.date,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      SizedBox(width: 10),
                      Icon(Icons.access_time, color: Colors.white, size: 16),
                      SizedBox(width: 3),
                      Text(
                        reservation.hourInfo,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Center(
                    child: Text(
                      "CHOOSE YOUR LOCATION",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white, // White text color
                      ),
                      textAlign:
                          TextAlign.center, // Ensures the text is centered
                    ),
                  ),
                ],
              ),
            ),
            // Second Section: White rectangle with location options
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                ),
                child: FutureBuilder<List<ParkingSpace>>(
                  future: _fetchParkingSpaces(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Center(
                          child: Text("Error loading parking spaces"));
                    } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      return Center(child: Text("No parking spaces available"));
                    }

                    final parkingSpaces = snapshot.data!;

                    return ListView.builder(
                      itemCount: parkingSpaces.length,
                      itemBuilder: (context, index) {
                        final parkingSpace = parkingSpaces[index];
                        return _buildLocationCard(
                          context: context,
                          parkingSpace: parkingSpace,
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationCard({
    required BuildContext context,
    required ParkingSpace parkingSpace,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white, // Background color
          border: Border.all(color: Colors.grey.withOpacity(0.6)),
          borderRadius: BorderRadius.circular(16), // Border radius
        ),
        child: Card(
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 2,
          child: Padding(
            padding:
                const EdgeInsets.symmetric(vertical: 16.0, horizontal: 12.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.location_pin, color: Color(0xFF54BBE6)),
                          SizedBox(width: 8),
                          Text(
                            parkingSpace.storeName,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF54BBE6),
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        "${parkingSpace.totalAvailableSpace} slots available",
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "Price start from",
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        "Rp ${parkingSpace.price} /hour",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 8),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ChooseLoc(
                                customer: customer,
                                reservation: reservation,
                                parkingSpace: parkingSpace,
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(),
                            backgroundColor: Color(0xFF54BBE6),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            fixedSize: Size(200, 48)),
                        child: Text(
                          "Park my car here",
                          style: TextStyle(color: Colors.white, fontSize: 14),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
