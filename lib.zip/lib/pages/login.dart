import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/security.dart';
import 'package:try3/models/staff.dart';
import 'package:try3/models/user.dart';
import 'package:try3/pages/securityDashboard.dart';
import 'package:try3/pages/staffDashboard.dart';
import 'forgotPass.dart';
import 'customerDashboard.dart';
import 'signUp.dart';

class login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<login> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  bool _isButtonEnabled = false; // Track the button state

  // Function to validate the fields
  void _validateFields() {
    setState(() {
      _isButtonEnabled = _usernameController.text.isNotEmpty &&
          _passwordController.text.isNotEmpty;
    });
  }

  Future<User?> _authenticateUser(String username, String password) async {
    try {
      username = username.trim();
      password = password.trim();

      print(
          "Attempting login with username: $username and password: $password");

      // Query the 'User' collection using username and password
      QuerySnapshot snapshot = await _firestore
          .collection('User')
          .where('username', isEqualTo: username)
          .where('password', isEqualTo: password)
          .get();

      print("Number of users found: ${snapshot.docs.length}");

      if (snapshot.docs.isNotEmpty) {
        DocumentSnapshot userDoc = snapshot.docs.first;

        int userID = userDoc.get('userID');
        String role = userDoc.get('role');
        print('User ID: $userID');
        print('User Role: $role');

        // Convert userID to string for Firestore document reference
        // Ensure userID is always converted to a String when used as a Firestore document reference
        String profileDocId = userDoc.get('userID').toString();

        if (role == "Customer") {
          DocumentSnapshot profileDoc =
              await _firestore.collection('Customer').doc(profileDocId).get();

          if (profileDoc.exists) {
            print('Customer profile data: ${profileDoc.data()}');
            return Customer.fromFirestore(profileDoc);
          } else {
            print('Customer profile document not found.');
          }
        } else if (role == "Staff") {
          DocumentSnapshot profileDoc =
              await _firestore.collection('Staff').doc(profileDocId).get();

          if (profileDoc.exists) {
            print('Staff profile data: ${profileDoc.data()}');
            return Customer.fromFirestore(profileDoc);
          } else {
            print('Staff profile document not found.');
          }
        } else if (role == "Security") {
          DocumentSnapshot profileDoc = await _firestore
              .collection('Security Personnel')
              .doc(profileDocId)
              .get();

          if (profileDoc.exists) {
            print('Security profile data: ${profileDoc.data()}');
            return Security.fromFirestore(profileDoc);
          } else {
            print('Security profile document not found.');
          }
        } else {
          print('Unhandled user role: $role');
        }
      } else {
        print('No matching user found.');
      }
    } catch (e) {
      print('Error during authentication: $e');
    }
    return null;
  }

  Future<void> _authenticateAndNavigate(
      String username, String password) async {
    try {
      // Authenticate the user
      var user = await _authenticateUser(username, password);

      if (user != null) {
        if (user is Customer) {
          // Navigate to Customer Dashboard
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => customerDashboard(customer: user),
            ),
          );
        } else if (user is Security) {
          // Navigate to Security Dashboard
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => securityDashboard(security: user),
            ),
          );
        } else if (user is Staff) {
          // Navigate to Security Dashboard
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => staffDashboard(),
            ),
          );
        } else {
          print("Unhandled user role: ${user.role}");
        }
      } else {
        // Handle authentication failure
        print("Authentication failed.");
      }
    } catch (e) {
      print("Error during authentication: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Container(
        width: screenWidth,
        height: screenHeight,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          image: const DecorationImage(
            image: AssetImage("lib/images/Clouds.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: screenWidth,
                  height: screenHeight * 0.2,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("lib/images/Group 19.png"),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Positioned(
                  top: 10,
                  child: Image.asset(
                    "lib/images/Group 21.png",
                    scale: 0.9,
                    width: screenWidth * 0.8,
                    height: screenHeight * 0.2,
                    fit: BoxFit.contain,
                  ),
                ),
              ],
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(30),
                  ),
                ),
                padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.1),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 20),
                    Text('Username', style: _inputLabelStyle()),
                    SizedBox(height: 8),
                    _buildTextField("Enter your Username", _usernameController),
                    SizedBox(height: 20),
                    Text('Password', style: _inputLabelStyle()),
                    SizedBox(height: 8),
                    _buildTextField("Enter your Password", _passwordController),
                    SizedBox(height: 20),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Forgotpass(
                                    username: _usernameController.text,
                                  )),
                        ),
                        child: Text(
                          'Forgot Password?',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 13,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ),
                    Spacer(),
                    Center(
                      child: Container(
                        width: screenWidth * 0.8,
                        height: 50,
                        decoration: BoxDecoration(
                          color: _isButtonEnabled
                              ? Color(0xFF278EA5)
                              : Colors.grey,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: Colors.black.withOpacity(0.67),
                            width: 1,
                          ),
                        ),
                        child: InkWell(
                          onTap: _isButtonEnabled
                              ? () async {
                                  await _authenticateAndNavigate(
                                    _usernameController.text,
                                    _passwordController.text,
                                  );
                                }
                              : null,
                          child: Center(
                            child: Text(
                              'Login',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('Don’t have an account?',
                              style: _inputLabelStyle()),
                          TextButton(
                            onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => Signup()),
                            ),
                            child: const Text(
                              'Sign Up',
                              style: TextStyle(
                                color: Color(0xFF278EA5),
                                fontSize: 15,
                                fontFamily: 'Poppins',
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  TextStyle _inputLabelStyle() {
    return TextStyle(
      color: Colors.black,
      fontSize: 15,
      fontFamily: 'Poppins',
      fontWeight: FontWeight.w400,
    );
  }

  Widget _buildTextField(String hintText, TextEditingController controller) {
    return TextField(
      controller: controller,
      onChanged: (text) => _validateFields(),
      obscureText: hintText.toLowerCase().contains("password"),
      style: TextStyle(
        color: Colors.black,
        fontSize: 14,
        fontFamily: 'Poppins',
        fontWeight: FontWeight.w400,
      ),
      decoration: InputDecoration(
        hintText: hintText,
        hintStyle: TextStyle(
          color: Colors.black.withOpacity(0.44),
          fontSize: 12,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
            color: Colors.black.withOpacity(0.67),
            width: 1,
          ),
        ),
      ),
    );
  }
}
