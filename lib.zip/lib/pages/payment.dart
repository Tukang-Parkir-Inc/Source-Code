import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/parking_space.dart';
import 'package:try3/models/reservation.dart';
import 'package:intl/intl.dart'; // For currency formatting
import 'ReservationCompletePage.dart';

class PaymentPage extends StatelessWidget {
  final ParkingSpace parkingSpace; // Parking space details
  final Reservation reservation; // Reservation details
  final Customer customer; // Customer details

  const PaymentPage({
    required this.customer,
    required this.parkingSpace,
    required this.reservation,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Extract details from reservation
    final String location = parkingSpace.storeName;
    final String reservationDate = reservation.date;
    final String hourInfo = reservation.hourInfo;
    final int totalHour = reservation.totalHour;
    final String slot = reservation.slot;
    final String totalPrice = NumberFormat.currency(
      locale: 'id_ID', // Indonesian locale
      symbol: 'Rp ',
    ).format(reservation.totalHour * parkingSpace.price);

    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Image.asset(
              'lib/images/Profile.png', // Replace with your image path
              fit: BoxFit.cover,
            ),
          ),
          // Foreground content
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppBar(
                  backgroundColor: Color(0xFF54BBE6),
                  title: const Text(
                    "Payment",
                    style: TextStyle(
                      color: Colors.white, // Use Colors.white
                    ),
                  ),
                  leading: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),

                const SizedBox(height: 16),
                // Reservation Details
                const Text(
                  "Reservation Details",
                  style: TextStyle(
                    color: Colors.blue,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  color: Colors.white.withOpacity(0.9),
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Location: $location",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Reservation Date: $reservationDate",
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Time: $hourInfo",
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Total Hour: $totalHour",
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Parking Slot: $slot",
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Total Payment
                const Text(
                  "Total Payment",
                  style: TextStyle(
                    color: Colors.blue,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  color: const Color.fromARGB(255, 112, 212, 201),
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Total Price",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        Text(
                          totalPrice,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),

                // Action Buttons
                Row(
                  children: [
                    // Cancel Button
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          minimumSize: const Size(double.infinity, 48),
                        ),
                        onPressed: () {
                          Navigator.pop(
                              context); // Navigate back to the previous screen
                        },
                        child: const Text(
                          "Cancel",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16), // Spacing between buttons

                    // Confirm Button
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          minimumSize: const Size(double.infinity, 48),
                        ),
                        onPressed: () async {
                          try {
                            // Query Firestore to locate the reservation document
                            final reservationQuery = await FirebaseFirestore
                                .instance
                                .collection('Reservation')
                                .where('reservationID',
                                    isEqualTo: reservation.reservationID)
                                .get();

                            if (reservationQuery.docs.isNotEmpty) {
                              final reservationDoc =
                                  reservationQuery.docs.first;

                              // Update the reservation status in Firestore
                              await reservationDoc.reference.update({
                                'status': 'reserved',
                                'slot': slot,
                                'totalPrice':
                                    reservation.totalHour * parkingSpace.price,
                                'location':
                                    location, // Add the calculated total price
                              });

                              // Update ParkingSpace document in Firestore
                              final parkingSpaceQuery = await FirebaseFirestore
                                  .instance
                                  .collection('Parking Space')
                                  .where('parkingID',
                                      isEqualTo: parkingSpace.parkingID)
                                  .get();

                              if (parkingSpaceQuery.docs.isNotEmpty) {
                                final parkingSpaceDoc =
                                    parkingSpaceQuery.docs.first;

                                // Get the current parking space data
                                ParkingSpace updatedParkingSpace =
                                    ParkingSpace.fromJson(
                                        parkingSpaceDoc.data());

                                // Update the slot status to false (booked)
                                updatedParkingSpace
                                    .slotStatus[reservation.slot] = false;

                                // Update total available and reserved spaces
                                updatedParkingSpace.totalAvailableSpace -= 1;
                                updatedParkingSpace.totalReservedSpace += 1;

                                // Save the updated parking space data back to Firestore
                                await FirebaseFirestore.instance
                                    .collection('Parking Space')
                                    .doc(
                                        parkingSpaceDoc.id) // Using document ID
                                    .update(updatedParkingSpace.toJson());

                                // Navigate to the reservation completion page
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        ReservationCompletePage(
                                            customer: customer),
                                  ),
                                );

                                // Show success message
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      "Payment Confirmed for ${totalHour} hour(s) at ${location}",
                                    ),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                              } else {
                                // Handle case where parking space document doesn't exist
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text("Parking space not found!"),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            } else {
                              // Handle the case where no matching reservation document is found
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text("Reservation not found!"),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          } catch (e) {
                            // Handle errors, such as network or permission issues
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text("Failed to confirm payment: $e"),
                                backgroundColor: Colors.red,
                              ),
                            );
                          }
                        },
                        child: const Text(
                          "Confirm",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
