import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/user.dart';
import 'login.dart';
import 'customerDashboard.dart';
import 'reservationPage.dart';

class Profile extends StatefulWidget {
  final Customer customer;
  const Profile({required this.customer, Key? key}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController plateNumController = TextEditingController();

  String profilePicture = "lib/images/billie.jpg"; // Default profile picture

  int _selectedIndex = 2;

  @override
  void initState() {
    super.initState();
    _populateFields();
  }

  void _populateFields() {
    emailController.text = widget.customer.email;
    fullNameController.text = widget.customer.fullName;
    usernameController.text = widget.customer.username;
    passwordController.text = widget.customer.password;
    addressController.text = widget.customer.address;
    plateNumController.text = widget.customer.plateNum;
  }

  Future<void> _updateUserModel(String newUsername, String newPassword) async {
    try {
      final userCollection = _firestore.collection('User');
      final userQuery = await userCollection
          .where('userID', isEqualTo: widget.customer.userID)
          .get();

      if (userQuery.docs.isNotEmpty) {
        final userDocRef = userQuery.docs.first.reference;
        await userDocRef.update({
          'username': newUsername,
          'password': newPassword,
        });
        print('User model updated successfully!');
      }
    } catch (e) {
      print('Error updating user model: $e');
    }
  }

  Future<void> _saveProfileChanges() async {
    try {
      final customerCollection = _firestore.collection('Customer');
      print(
          'Updating profile for Customer with userID: ${widget.customer.userID}');

      final existingUserQuery = await customerCollection
          .where('userID', isEqualTo: widget.customer.userID)
          .get();

      if (existingUserQuery.docs.isEmpty) {
        print('Customer document not found. Cannot update profile.');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content:
                  Text('Customer record not found. Please contact support.')),
        );
        return;
      }

      final customerDocRef = existingUserQuery.docs.first.reference;

      // Check if username needs updating
      if (usernameController.text != widget.customer.username) {
        final usernameQuery = await customerCollection
            .where('username', isEqualTo: usernameController.text)
            .get();

        if (usernameQuery.docs.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content:
                    Text('Username already taken. Please choose another one.')),
          );
          return;
        }
      }

      // Check if password needs updating
      bool isPasswordChanged =
          passwordController.text != widget.customer.password;

      // Update Firestore document
      await customerDocRef.update({
        'email': emailController.text,
        'fullName': fullNameController.text,
        'username': usernameController.text,
        'password': passwordController.text,
        'address': addressController.text,
        'plateNum': plateNumController.text,
      });

      // Update Firestore document
      await customerDocRef.update({
        'email': emailController.text,
        'fullName': fullNameController.text,
        'username': usernameController.text,
        'password': passwordController.text,
        'address': addressController.text,
        'plateNum': plateNumController.text,
      });

      if (usernameController.text != widget.customer.username ||
          isPasswordChanged) {
        await _updateUserModel(
            usernameController.text, passwordController.text);
      }

      setState(() {});

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Profile updated successfully!')),
      );
    } catch (e) {
      print('Error saving profile changes: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Failed to update profile. Please try again later.')),
      );
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => customerDashboard(customer: widget.customer),
          ),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => reservationPage(customer: widget.customer),
          ),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => Profile(customer: widget.customer),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFF54BBE6),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.car_rental),
            label: 'Patrol Status',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_box),
            label: 'Profile',
          ),
        ],
      ),
      body: Container(
        width: screenWidth,
        height: screenHeight,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("lib/images/Profile.png"),
            fit: BoxFit.fill,
          ),
        ),
        child: Column(
          children: [
            Container(
              color: Colors.white,
              height: 84,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            customerDashboard(customer: widget.customer),
                      ),
                    ),
                    child: const Icon(Icons.arrow_back,
                        size: 24, color: Color(0xFF54BBE6)),
                  ),
                  const SizedBox(width: 16),
                  const Text(
                    'Profile',
                    style: TextStyle(
                      color: Color(0xFF54BBE6),
                      fontSize: 18,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            CircleAvatar(
              radius: 52,
              backgroundImage: AssetImage(profilePicture),
            ),
            TextButton(
              onPressed: () {
                // Allow user to upload and change profile picture
              },
              child: const Text(
                'Edit Picture',
                style: TextStyle(
                  color: Color(0xFF54BBE6),
                  fontSize: 15,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 16),
            EditableProfileInfoRow(label: 'Email', controller: emailController),
            EditableProfileInfoRow(
                label: 'Full Name', controller: fullNameController),
            EditableProfileInfoRow(
                label: 'Username', controller: usernameController),
            EditableProfileInfoRow(
                label: 'Password',
                controller: passwordController,
                isPassword: true),
            EditableProfileInfoRow(
                label: 'Address', controller: addressController),
            EditableProfileInfoRow(
                label: 'Plate Number', controller: plateNumController),
            const Spacer(),
            ElevatedButton(
              onPressed: _saveProfileChanges,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF278EA5),
                side: BorderSide(color: Colors.black),
                padding:
                    const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              ),
              child: const Text(
                'Save Changes',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => login()),
              ),
              child: const Text(
                'Log Out',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class EditableProfileInfoRow extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final bool isPassword;

  EditableProfileInfoRow({
    required this.label,
    required this.controller,
    this.isPassword = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          // Label on the left
          Expanded(
            flex: 3,
            child: Text(
              label,
              style: TextStyle(
                color: Colors.black,
                fontSize: 15,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
          // Input field on the right
          Expanded(
            flex: 7,
            child: TextFormField(
              controller: controller,
              obscureText: isPassword,
              style: TextStyle(
                color: Colors.black, // Text color
                fontWeight: FontWeight.bold, // Bold text
                fontSize: 15, // Font size to match design
              ),
              decoration: InputDecoration(
                contentPadding: EdgeInsets.symmetric(horizontal: 8),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
