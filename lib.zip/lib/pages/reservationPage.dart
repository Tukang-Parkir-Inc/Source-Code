import 'package:flutter/material.dart';
import 'package:try3/models/customer.dart';
import 'package:try3/models/reservation.dart';
import 'profile.dart';
import 'customerDashboard.dart';
import 'location.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class reservationPage extends StatefulWidget {
  final Customer customer; // Add Customer object

  const reservationPage({required this.customer, Key? key}) : super(key: key);

  @override
  _ReservationPageState createState() => _ReservationPageState();
}

class _ReservationPageState extends State<reservationPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _totalController = TextEditingController();
  final TextEditingController _hourController = TextEditingController();
  int _selectedIndex = 1;
  bool _isButtonEnabled = false;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        // Navigate to Home screen
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  customerDashboard(customer: widget.customer)),
        );
        break;
      case 1:
        // Navigate to Reserve screen
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => reservationPage(customer: widget.customer)),
        );
        break;
      case 2:
        // Navigate to Profile screen
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => Profile(customer: widget.customer)),
        );
        break;
    }
  }

  @override
  void initState() {
    super.initState();

    // Add listeners to input fields
    _dateController.addListener(_checkInputValidity);
    _totalController.addListener(_checkInputValidity);
    _hourController.addListener(_checkInputValidity);
  }

  void _checkInputValidity() {
    final isDateFilled = _dateController.text.isNotEmpty;
    final isTotalHourValid = int.tryParse(_totalController.text) != null &&
        int.tryParse(_totalController.text)! > 0;

    // Validate hour input with specific constraints (0-24 for hours, 00-59 for minutes)
    final isStartHourValid = RegExp(r'^(?:[0-9]|1[0-9]|2[0-3])\.[0-5][0-9]$')
        .hasMatch(_hourController.text);

    setState(() {
      _isButtonEnabled = isDateFilled && isTotalHourValid && isStartHourValid;
    });
  }

  @override
  void dispose() {
    // Dispose controllers to avoid memory leaks
    _dateController.dispose();
    _totalController.dispose();
    _hourController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );

    if (pickedDate != null) {
      setState(() {
        _dateController.text = DateFormat('yyyy-MM-dd').format(pickedDate);
      });
    }
  }

  Future<void> _saveReservation() async {
    String date = _dateController.text;
    int? totalHour = int.tryParse(_totalController.text);
    double? startHour = double.tryParse(_hourController.text);

    if (totalHour == null || startHour == null || date.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please fill all fields correctly.')),
      );
      return;
    }

    double finishHour = startHour + totalHour;

    // Generate a unique reservation ID
    int reservationID = DateTime.now().millisecondsSinceEpoch;

    // Create the reservation object
    Reservation reservation = Reservation(
      userID: widget.customer.userID,
      date: date,
      hourInfo:
          '${startHour.toStringAsFixed(2)} - ${finishHour.toStringAsFixed(2)}',
      totalHour: totalHour,
      reservationID: reservationID,
    );

    try {
      // Reference to the Firestore 'Reservation' collection
      final reservationRef = _firestore.collection('Reservation');

      // Use `userID` to find the customer
      final customerQuery = await _firestore
          .collection('Customer')
          .where('userID', isEqualTo: widget.customer.userID)
          .get();

      if (customerQuery.docs.isEmpty) {
        throw Exception(
            'Customer with userID ${widget.customer.userID} not found.');
      }

      final customerDoc = customerQuery.docs.first.reference;

      // Set the reservation document with `reservationID` as the document ID
      await reservationRef
          .doc(reservationID.toString())
          .set(reservation.toJson());

      // Update the customer's history array with the `reservationID`
      await customerDoc.update({
        'history': FieldValue.arrayUnion([reservationID]),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Reservation added successfully!')),
      );

      // Navigate to the location selection page
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ReservationLoc(
              customer: widget.customer, reservation: reservation),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to add reservation: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFF54BBE6),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.car_rental),
            label: 'Reserve',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_box),
            label: 'Profile',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('lib/images/bg reservation.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          children: [
            Container(
              color: Colors.white,
              height: 84,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              customerDashboard(customer: widget.customer)),
                    ),
                    child: Icon(Icons.arrow_back,
                        size: 24, color: Color(0xFF54BBE6)),
                  ),
                  SizedBox(width: 16),
                  Text(
                    'Reservation',
                    style: TextStyle(
                      color: Color(0xFF54BBE6),
                      fontSize: 18,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Container(
              width: screenWidth * 0.9,
              height: screenWidth * 0.4,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("lib/images/Group 21.png"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.1),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 10),
                  _buildFieldLabel('Reservation Date'),
                  SizedBox(height: 8),
                  _buildDateField(),
                  SizedBox(height: 20),
                  _buildFieldLabel('Total Book Hour'),
                  SizedBox(height: 8),
                  _buildTotalHourField(),
                  SizedBox(height: 20),
                  _buildFieldLabel('Start Hour'),
                  SizedBox(height: 8),
                  _buildStartHourField(),
                  SizedBox(height: 20),
                ],
              ),
            ),
            SizedBox(height: 20),
            Center(
              child: Container(
                width: screenWidth * 0.8,
                height: 50,
                decoration: BoxDecoration(
                  color: _isButtonEnabled
                      ? Color(0xFF278EA5)
                      : Colors.grey, // Change color based on button state
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.black,
                    width: 1,
                  ),
                ),
                child: InkWell(
                  onTap: _isButtonEnabled
                      ? () async {
                          await _saveReservation();
                        }
                      : null,
                  child: Center(
                    child: Text(
                      'Find Location',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: screenWidth,
                  height: 68,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("lib/images/Group 14.png"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFieldLabel(String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 20),
        Text(
          label,
          style: const TextStyle(
            color: Colors.black,
            fontSize: 15,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
          ),
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _buildDateField() {
    return TextField(
      controller: _dateController,
      readOnly: true,
      decoration: InputDecoration(
        hintText: "Select Date",
        hintStyle: TextStyle(
          color: Colors.grey, // Adjust hint text color if needed
        ),
        filled: true,
        fillColor: Colors.white,
        suffixIcon: Icon(Icons.calendar_today, color: Colors.grey),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      style: TextStyle(
        color: Colors.black, // Set input text color to black
      ),
      onTap: () => _selectDate(context),
    );
  }

  Widget _buildTotalHourField() {
    return TextField(
      controller: _totalController,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        hintText: "Enter Total Hours in Integer (e.g., 3)",
        hintStyle: TextStyle(
          color: Colors.grey, // Adjust hint text color if needed
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      style: TextStyle(
        color: Colors.black, // Set input text color to black
      ),
    );
  }

  Widget _buildStartHourField() {
    return TextField(
      controller: _hourController,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        hintText: "Enter Start Hour (e.g., 17.00)",
        hintStyle: TextStyle(
          color: Colors.grey, // Adjust hint text color if needed
        ),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      style: TextStyle(
        color: Colors.black, // Set input text color to black
      ),
    );
  }
}
