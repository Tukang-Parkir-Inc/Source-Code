import 'package:flutter/material.dart';
import 'package:try3/pages/ParkingLocStatus.dart';
import 'package:try3/models/security.dart';
import 'package:try3/pages/securityProfile.dart';
import 'PatrolStatusPage.dart';

class securityDashboard extends StatefulWidget {
  final Security security;

  const securityDashboard({required this.security, Key? key}) : super(key: key);

  @override
  _securityDashboardState createState() => _securityDashboardState();
}

class _securityDashboardState extends State<securityDashboard> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        // Navigate to Home screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => securityDashboard(security: widget.security),
          ),
        );
        break;
      case 1:
        // Navigate to Reserve screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PatrolStatusPage(security: widget.security),
          ),
        );
        break;
      case 2:
        // Navigate to Profile screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => securityProfile(security: widget.security),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Stack(
        children: [
          // Background image: Clouds
          Positioned.fill(
            child: Image.asset(
              "lib/images/Clouds.png",
              fit: BoxFit.cover,
            ),
          ),

          // Your existing layout (now inside the Stack)
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20.0, vertical: 10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Hi, have a nice day!',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 15,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    CircleAvatar(
                      radius: 18,
                      backgroundImage: AssetImage("lib/images/billie.jpg"),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildIconButton(
                      'Parking status',
                      Color(0xFF54BBE6),
                      'lib/images/Vector.png',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ParkingLocStatus(
                              security: widget.security,
                            ),
                          ),
                        );
                      },
                    ),
                    _buildIconButton(
                      'Patrol Status',
                      Color(0xFF54BBE6),
                      'lib/images/status.png',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                PatrolStatusPage(security: widget.security),
                          ),
                        );
                      },
                    ),
                    _buildIconButton(
                      'Update Profile',
                      Color(0xFF54BBE6),
                      'lib/images/Group (1).png',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  securityProfile(security: widget.security)),
                        );
                      },
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    // Group 19 Image
                    Container(
                      width: screenWidth,
                      height: screenHeight * 0.25,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage("lib/Group 19.png"),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    // Group 14 Image
                    Container(
                      width: screenWidth,
                      height: 68,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage("lib/Group 14.png"),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    // Positioned widget on top of the Clouds background
                    Positioned(
                      // Adjust relative to screen width
                      top: screenHeight *
                          0.2, // Adjust relative to screen height
                      child: Container(
                        width: screenWidth * 0.9, // 80% of screen width
                        height: screenHeight * 0.2, // 20% of screen height
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage("lib/images/Group 21.png"),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFF54BBE6),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Patrol Status',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Profile',
          ),
        ],
      ),
    );
  }

  Widget _buildIconButton(String label, Color color, String imagePath,
      {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap, // Assign the onTap callback here.
      child: Column(
        children: [
          Container(
            width: 63,
            height: 47,
            decoration: BoxDecoration(
              color: Colors.teal,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Center(
              child: Image.asset(
                imagePath,
                width: 24, // Adjust width as needed.
                height: 24, // Adjust height as needed.
                fit: BoxFit
                    .contain, // Ensures the image fits inside the container.
              ),
            ),
          ),
          SizedBox(height: 5),
          Text(
            label.replaceAll(' ', '\n'),
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black,
              fontSize: 14,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }
}
