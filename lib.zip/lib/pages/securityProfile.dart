import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/security.dart';
import 'package:try3/pages/PatrolStatusPage.dart';
import 'package:try3/pages/securityDashboard.dart';
import 'login.dart';

class securityProfile extends StatefulWidget {
  final Security security;
  const securityProfile({required this.security, Key? key}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<securityProfile> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController departmentStoreController =
      TextEditingController();

  String profilePicture = "lib/images/billie.jpg"; // Default profile picture

  int _selectedIndex = 2;

  @override
  void initState() {
    super.initState();
    _populateFields();
  }

  void _populateFields() {
    emailController.text = widget.security.email;
    fullNameController.text = widget.security.fullName;
    usernameController.text = widget.security.username;
    passwordController.text = widget.security.password;
    addressController.text = widget.security.address;
    departmentStoreController.text = widget.security.departmentStore;
  }

  Future<void> _updateUserModel(String newUsername, String newPassword) async {
    try {
      final userCollection = _firestore.collection('User');
      final userQuery = await userCollection
          .where('userID', isEqualTo: widget.security.userID)
          .get();

      if (userQuery.docs.isNotEmpty) {
        final userDocRef = userQuery.docs.first.reference;
        await userDocRef.update({
          'username': newUsername,
          'password': newPassword,
        });
        print('User model updated successfully!');
      }
    } catch (e) {
      print('Error updating user model: $e');
    }
  }

  Future<void> _saveProfileChanges() async {
    try {
      final securityCollection = _firestore.collection('Security Personnel');
      print(
          'Updating profile for Security with userID: ${widget.security.userID}');

      final existingUserQuery = await securityCollection
          .where('userID', isEqualTo: widget.security.userID)
          .get();

      if (existingUserQuery.docs.isEmpty) {
        print('Security document not found. Cannot update profile.');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content:
                  Text('Security record not found. Please contact support.')),
        );
        return;
      }

      final securityDocRef = existingUserQuery.docs.first.reference;

      // Check if username needs updating
      if (usernameController.text != widget.security.username) {
        final usernameQuery = await securityCollection
            .where('username', isEqualTo: usernameController.text)
            .get();

        if (usernameQuery.docs.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content:
                    Text('Username already taken. Please choose another one.')),
          );
          return;
        }
      }

      // Check if password needs updating
      bool isPasswordChanged =
          passwordController.text != widget.security.password;

      // Update Firestore document
      await securityDocRef.update({
        'email': emailController.text,
        'fullName': fullNameController.text,
        'username': usernameController.text,
        'password': passwordController.text,
        'address': addressController.text,
        'departmentStore': departmentStoreController.text,
      });

      // Update Firestore document
      await securityDocRef.update({
        'email': emailController.text,
        'fullName': fullNameController.text,
        'username': usernameController.text,
        'password': passwordController.text,
        'address': addressController.text,
        'departmentStore': departmentStoreController.text,
      });

      if (usernameController.text != widget.security.username ||
          isPasswordChanged) {
        await _updateUserModel(
            usernameController.text, passwordController.text);
      }

      setState(() {});

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Profile updated successfully!')),
      );
    } catch (e) {
      print('Error saving profile changes: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Failed to update profile. Please try again later.')),
      );
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        // Navigate to Home screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => securityDashboard(security: widget.security),
          ),
        );
        break;
      case 1:
        // Navigate to Reserve screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PatrolStatusPage(security: widget.security),
          ),
        );
        break;
      case 2:
        // Navigate to Profile screen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => securityProfile(security: widget.security),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFF54BBE6),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Reserve',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_box),
            label: 'Profile',
          ),
        ],
      ),
      body: Container(
        width: screenWidth,
        height: screenHeight,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("lib/images/Profile.png"),
            fit: BoxFit.fill,
          ),
        ),
        child: Column(
          children: [
            Container(
              color: Colors.white,
              height: 84,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            securityDashboard(security: widget.security),
                      ),
                    ),
                    child: const Icon(Icons.arrow_back,
                        size: 24, color: Color(0xFF54BBE6)),
                  ),
                  const SizedBox(width: 16),
                  const Text(
                    'Profile',
                    style: TextStyle(
                      color: Color(0xFF54BBE6),
                      fontSize: 18,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            CircleAvatar(
              radius: 52,
              backgroundImage: AssetImage(profilePicture),
            ),
            TextButton(
              onPressed: () {
                // Allow user to upload and change profile picture
              },
              child: const Text(
                'Edit Picture',
                style: TextStyle(
                  color: Color(0xFF54BBE6),
                  fontSize: 15,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 16),
            EditableProfileInfoRow(label: 'Email', controller: emailController),
            EditableProfileInfoRow(
                label: 'Full Name', controller: fullNameController),
            EditableProfileInfoRow(
                label: 'Username', controller: usernameController),
            EditableProfileInfoRow(
                label: 'Password',
                controller: passwordController,
                isPassword: true),
            EditableProfileInfoRow(
                label: 'Address', controller: addressController),
            EditableProfileInfoRow(
                label: 'Department Store',
                controller: departmentStoreController),
            const Spacer(),
            ElevatedButton(
              onPressed: _saveProfileChanges,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF278EA5),
                side: BorderSide(color: Colors.black),
                padding:
                    const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              ),
              child: const Text(
                'Save Changes',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => login()),
              ),
              child: const Text(
                'Log Out',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class EditableProfileInfoRow extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final bool isPassword;

  EditableProfileInfoRow({
    required this.label,
    required this.controller,
    this.isPassword = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          // Label on the left
          Expanded(
            flex: 3,
            child: Text(
              label,
              style: TextStyle(
                color: Colors.black,
                fontSize: 15,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
          // Input field on the right
          Expanded(
            flex: 7,
            child: TextFormField(
              controller: controller,
              obscureText: isPassword,
              style: TextStyle(
                color: Colors.black, // Text color
                fontWeight: FontWeight.bold, // Bold text
                fontSize: 15, // Font size to match design
              ),
              decoration: InputDecoration(
                contentPadding: EdgeInsets.symmetric(horizontal: 8),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
