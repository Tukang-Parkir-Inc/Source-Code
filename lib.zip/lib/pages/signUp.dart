import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:try3/models/user.dart';
import 'login.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:try3/models/customer.dart';

class Signup extends StatefulWidget {
  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _plateNumberController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isButtonEnabled = false;

  @override
  void initState() {
    super.initState();
    _addValidationListeners();
  }

  void _addValidationListeners() {
    for (var controller in [
      _usernameController,
      _fullNameController,
      _emailController,
      _addressController,
      _plateNumberController,
      _passwordController
    ]) {
      controller.addListener(_validateFields);
    }
  }

  void _validateFields() {
    setState(() {
      _isButtonEnabled = _usernameController.text.isNotEmpty &&
          _fullNameController.text.isNotEmpty &&
          _emailController.text.isNotEmpty &&
          _addressController.text.isNotEmpty &&
          _plateNumberController.text.isNotEmpty &&
          _passwordController.text.isNotEmpty;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          image: DecorationImage(
            image: AssetImage("lib/images/Sign Up.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => login()),
                        ),
                      ),
                      SizedBox(width: 16),
                      Text(
                        'Sign Up',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Center(
                    child: Text(
                      'Create Account',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  SizedBox(height: 40),
                  buildInputField(
                    controller: _usernameController,
                    label: 'Username',
                    hint: 'Enter your Username',
                  ),
                  SizedBox(height: 10),
                  buildInputField(
                    controller: _fullNameController,
                    label: 'Full Name',
                    hint: 'Enter your Full Name',
                  ),
                  SizedBox(height: 10),
                  buildInputField(
                    controller: _emailController,
                    label: 'Email',
                    hint: 'Enter your Email',
                    keyboardType: TextInputType.emailAddress,
                  ),
                  SizedBox(height: 10),
                  buildInputField(
                    controller: _addressController,
                    label: 'Address',
                    hint: 'Enter your Address',
                  ),
                  SizedBox(height: 10),
                  buildInputField(
                    controller: _plateNumberController,
                    label: 'Plate Number',
                    hint: 'Enter your Plate Number',
                  ),
                  SizedBox(height: 10),
                  buildInputField(
                    controller: _passwordController,
                    label: 'Password',
                    hint: 'Enter your Password',
                    obscureText: true,
                  ),
                  SizedBox(height: 30),
                  Center(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            _isButtonEnabled ? Color(0xFF278EA5) : Colors.grey,
                        minimumSize:
                            Size(MediaQuery.of(context).size.width * 0.8, 50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      onPressed: _isButtonEnabled ? _handleSignUp : null,
                      child: Text(
                        'Sign Up',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'Poppins',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Center(
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: 'Already have an account? ',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 13,
                              fontFamily: 'Inter',
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                          TextSpan(
                            text: 'Log In',
                            style: TextStyle(
                              color: Color(0xFF278EA5),
                              fontSize: 13,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400,
                              decoration: TextDecoration.underline,
                            ),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => login()),
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _handleSignUp() async {
    try {
      // Check for existing username
      QuerySnapshot existingUser = await _firestore
          .collection('User')
          .where('username', isEqualTo: _usernameController.text)
          .get();

      if (existingUser.docs.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content:
                Text('Username already exists. Please choose another one.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      // Generate a unique user ID
      int userID = DateTime.now().millisecondsSinceEpoch;

      Customer newCustomer = Customer(
        userID: userID,
        username: _usernameController.text,
        password: _passwordController.text,
        role: 'Customer',
        address: _addressController.text,
        email: _emailController.text,
        fullName: _fullNameController.text,
        plateNum: _plateNumberController.text,
      );

      // Add Customer to Firestore
      await _firestore
          .collection('Customer')
          .doc(userID.toString())
          .set(newCustomer.toJson());

      User newUser = User(
        userID: userID,
        username: newCustomer.username,
        password: newCustomer.password,
        role: newCustomer.role,
      );

      // Add User to Firestore
      await _firestore
          .collection('User')
          .doc(userID.toString())
          .set(newUser.toJson());

      // Navigate to customer dashboard
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => login(),
        ),
      );
    } catch (e) {
      print('Error during sign-up: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to sign up. Please try again later.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Widget buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.black,
            fontSize: 15,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
          ),
        ),
        SizedBox(height: 7),
        TextField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          style: TextStyle(
            color: Colors.black,
            fontSize: 14,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.w400,
          ),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(
              color: Colors.black.withOpacity(0.5),
              fontSize: 12,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide(color: Colors.black, width: 1),
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    for (var controller in [
      _usernameController,
      _fullNameController,
      _emailController,
      _addressController,
      _plateNumberController,
      _passwordController
    ]) {
      controller.dispose();
    }
    super.dispose();
  }
}
